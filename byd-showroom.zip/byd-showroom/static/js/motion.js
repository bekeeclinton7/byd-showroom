/**
 * motion.js — Page-load choreography, scroll reveals, header behaviour,
 * mobile menu and launch countdown timers.
 *
 * Motion principles: fast (150–700ms), eased with cubic-bezier(0.22, 1, 0.36, 1),
 * transform/opacity only, and fully disabled for prefers-reduced-motion.
 */

export const prefersReducedMotion = () =>
  window.matchMedia("(prefers-reduced-motion: reduce)").matches;

/* Remove the stagger delay once an element has finished revealing so later
   hover transitions (card lift etc.) respond instantly. */
function clearDelayAfterReveal(el) {
  const done = () => el.style.removeProperty("--delay");
  el.addEventListener("transitionend", done, { once: true });
  setTimeout(done, 1600);
}

/* ---------------------------------------------------------------- page load */
function initLoadSequence() {
  const els = [...document.querySelectorAll("[data-load]")];
  els.forEach((el, i) => el.style.setProperty("--delay", `${Math.min(i * 80, 640)}ms`));
  // Two frames so the initial (hidden) state is committed before transitioning.
  requestAnimationFrame(() => requestAnimationFrame(() => {
    els.forEach((el) => { el.classList.add("is-in"); clearDelayAfterReveal(el); });
  }));
}

/* ------------------------------------------------------------ scroll reveal */
let observer = null;

/** Observe [data-reveal] elements inside root. Safe to call repeatedly
 *  (e.g. after the showroom grid re-renders). */
export function observeReveals(root = document) {
  const els = [...root.querySelectorAll("[data-reveal]:not(.is-in)")];
  if (!("IntersectionObserver" in window) || prefersReducedMotion()) {
    els.forEach((el) => el.classList.add("is-in"));
    return;
  }
  if (!observer) {
    observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add("is-in");
        clearDelayAfterReveal(entry.target);
        observer.unobserve(entry.target);
      });
    }, { rootMargin: "0px 0px -8% 0px", threshold: 0.08 });
  }
  els.forEach((el) => {
    // Siblings inside a [data-stagger] container cascade in, 80ms apart per row of 4.
    const group = el.parentElement && el.parentElement.closest("[data-stagger]");
    if (group) {
      const siblings = [...group.querySelectorAll(":scope > [data-reveal], :scope > li > [data-reveal]")];
      const idx = siblings.indexOf(el);
      if (idx > -1) el.style.setProperty("--delay", `${(idx % 4) * 80}ms`);
    }
    observer.observe(el);
  });
}

/* ------------------------------------------------------------------ header */
function initHeader() {
  const header = document.getElementById("site-header");
  if (!header) return;
  let ticking = false;
  const update = () => {
    header.classList.toggle("is-scrolled", window.scrollY > 8);
    ticking = false;
  };
  window.addEventListener("scroll", () => {
    if (!ticking) { requestAnimationFrame(update); ticking = true; }
  }, { passive: true });
  update();

  // Mobile menu
  const toggle = document.querySelector("[data-menu-toggle]");
  const nav = document.getElementById("site-nav");
  if (!toggle || !nav) return;
  const setOpen = (open) => {
    nav.classList.toggle("is-open", open);
    toggle.setAttribute("aria-expanded", String(open));
    toggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
  };
  toggle.addEventListener("click", () => setOpen(!nav.classList.contains("is-open")));
  nav.addEventListener("click", (e) => { if (e.target.closest("a")) setOpen(false); });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && nav.classList.contains("is-open")) { setOpen(false); toggle.focus(); }
  });
  window.matchMedia("(min-width: 901px)").addEventListener("change", (e) => { if (e.matches) setOpen(false); });
}

/* --------------------------------------------------------------- countdown */
const UNITS = [["days", 86400], ["hrs", 3600], ["min", 60], ["sec", 1]];

function buildCountdown(el) {
  el.innerHTML = UNITS.map(([label], i) =>
    `${i ? '<span class="countdown__sep" aria-hidden="true">:</span>' : ""}` +
    `<span class="countdown__unit"><span class="countdown__num" data-unit="${label}">00</span>` +
    `<span class="countdown__label">${label}</span></span>`).join("");
  return Object.fromEntries(UNITS.map(([label]) => [label, el.querySelector(`[data-unit="${label}"]`)]));
}

function initCountdowns() {
  const timers = [...document.querySelectorAll("[data-countdown]")].map((el) => {
    const deadline = Date.parse(el.dataset.countdown);
    return { el, deadline, nodes: Number.isNaN(deadline) ? null : buildCountdown(el) };
  }).filter((t) => t.nodes);
  if (!timers.length) return;

  const tick = () => {
    const now = Date.now();
    timers.forEach((t) => {
      let left = Math.max(0, Math.floor((t.deadline - now) / 1000));
      if (left === 0) {
        t.el.innerHTML = '<span class="subtle">Launch pricing has ended</span>';
        t.nodes = null;
        return;
      }
      if (!t.nodes) return;
      UNITS.forEach(([label, secs]) => {
        const value = String(Math.floor(left / secs)).padStart(2, "0");
        left %= secs;
        const node = t.nodes[label];
        if (node.textContent !== value) {
          node.textContent = value;
          if (!prefersReducedMotion()) {
            node.classList.remove("flip");
            void node.offsetWidth; // restart the flip animation
            node.classList.add("flip");
          }
        }
      });
    });
  };
  tick();
  setInterval(tick, 1000);
}

/* ------------------------------------------------------------ image fade-in */
/** Fade images in once decoded (used for client-rendered cards). */
export function fadeInImages(root = document) {
  root.querySelectorAll("img.img-fade:not(.is-loaded)").forEach((img) => {
    const done = () => img.classList.add("is-loaded");
    if (img.complete && img.naturalWidth) done();
    else {
      img.addEventListener("load", done, { once: true });
      img.addEventListener("error", done, { once: true });
    }
  });
}

export function initMotion() {
  initLoadSequence();
  observeReveals();
  initHeader();
  initCountdowns();
  fadeInImages();
}
