/**
 * pages/showroom.js — Filterable, sortable lineup with compare selection.
 *
 * Filtering runs on the server (/api/vehicles) so the API is the single source
 * of truth. Filter state is mirrored in the URL (shareable) and the compare
 * selection is kept in localStorage so it survives navigation to /compare.
 */
import { api } from "../api.js";
import { cad, esc, debounce } from "../format.js";
import { icon } from "../icons.js";
import { observeReveals, fadeInImages } from "../motion.js";
import { toast } from "../toast.js";

const COMPARE_KEY = "byd-compare";
const MAX_COMPARE = 3;
const DEFAULTS = { q: "", body: [], max_price: "75000", min_range: "0", seats: "0", sort: "price-asc" };

let vehicles = [];
let names = {};
let compare = [];
let requestId = 0;

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

/* --------------------------------------------------------------- state ---- */
function readState() {
  const q = new URLSearchParams(location.search);
  return {
    q: q.get("q") || DEFAULTS.q,
    body: (q.get("body") || "").split(",").filter(Boolean),
    max_price: q.get("max_price") || DEFAULTS.max_price,
    min_range: q.get("min_range") || DEFAULTS.min_range,
    seats: q.get("seats") || DEFAULTS.seats,
    sort: q.get("sort") || DEFAULTS.sort,
  };
}

function collectState() {
  return {
    q: $('[data-filter="q"]').value.trim(),
    body: $$('input[name="body"]:checked').map((i) => i.value),
    max_price: $('[data-filter="max_price"]').value,
    min_range: $('[data-filter="min_range"]').value,
    seats: ($('input[name="seats"]:checked') || { value: "0" }).value,
    sort: $('[data-filter="sort"]').value,
  };
}

function applyStateToControls(s) {
  $('[data-filter="q"]').value = s.q;
  $$('input[name="body"]').forEach((i) => { i.checked = s.body.includes(i.value); });
  $('[data-filter="max_price"]').value = s.max_price;
  $('[data-filter="min_range"]').value = s.min_range;
  $$('input[name="seats"]').forEach((i) => { i.checked = i.value === s.seats; });
  $('[data-filter="sort"]').value = s.sort;
  updateRangeOutputs();
}

function toParams(s) {
  const p = new URLSearchParams();
  if (s.q) p.set("q", s.q);
  if (s.body.length) p.set("body", s.body.join(","));
  if (s.max_price !== DEFAULTS.max_price) p.set("max_price", s.max_price);
  if (s.min_range !== DEFAULTS.min_range) p.set("min_range", s.min_range);
  if (s.seats !== DEFAULTS.seats) p.set("seats", s.seats);
  if (s.sort !== DEFAULTS.sort) p.set("sort", s.sort);
  return p;
}

/* Range sliders: fill the track up to the thumb and show the value. */
function updateRangeOutputs() {
  $$("input.range").forEach((r) => {
    const pct = ((r.value - r.min) / (r.max - r.min)) * 100;
    r.style.setProperty("--fill", `${pct}%`);
  });
  const price = $('[data-filter="max_price"]');
  const range = $('[data-filter="min_range"]');
  $('[data-out="max_price"]').textContent = price.value === price.max ? "Any" : `Up to ${cad(Number(price.value))}`;
  $('[data-out="min_range"]').textContent = range.value === "0" ? "Any" : `${range.value}+ km`;
}

/* -------------------------------------------------------------- fetch ---- */
async function refresh() {
  const state = collectState();
  const params = toParams(state);
  history.replaceState(null, "", params.toString() ? `?${params}` : location.pathname);

  const id = ++requestId;
  const results = $("[data-results]");
  results.setAttribute("aria-busy", "true");
  try {
    const data = await api(`/api/vehicles?${params}`);
    if (id !== requestId) return; // a newer filter change superseded this one
    vehicles = data.vehicles;
    render();
  } catch (err) {
    if (id !== requestId) return;
    $("[data-result-count]").textContent = "Could not load models.";
    toast(err.message, { type: "error" });
  } finally {
    if (id === requestId) results.setAttribute("aria-busy", "false");
  }
}

/* ------------------------------------------------------------- render ---- */
/** Client-side twin of the vehicle_card macro in templates/macros.html. */
function cardTemplate(v) {
  const selected = compare.includes(v.id);
  return `
  <article class="vehicle-card" data-reveal data-id="${esc(v.id)}">
    <div class="vehicle-card__media">
      <img class="img-fade" src="${esc(v.card_image)}" alt="${esc(v.full_name)} in ${esc(v.colours[0].name)}, studio photo" loading="lazy" decoding="async" width="1600" height="818">
      <div class="vehicle-card__badges">
        <span class="badge badge--dark">${esc(v.status)}</span>
        <span class="badge badge--red">${icon("tag")}Save ${cad(v.preorder.discount)}</span>
      </div>
    </div>
    <div class="vehicle-card__body">
      <div class="vehicle-card__title">
        <div>
          <h3><a href="/vehicle/${esc(v.id)}">${esc(v.name)}</a></h3>
          <p class="vehicle-card__tagline">${esc(v.body)} &middot; ${v.seats} seats</p>
        </div>
        <div class="vehicle-card__price"><span>From</span><strong>${cad(v.price_from)}</strong></div>
      </div>
      <div class="spec-row">
        <div class="spec"><span class="spec__label">${icon("route")}Range</span><span class="spec__value">${v.range_max}<small>km</small></span></div>
        <div class="spec"><span class="spec__label">${icon("zap")}Power</span><span class="spec__value">${v.power_max}<small>hp</small></span></div>
        <div class="spec"><span class="spec__label">${icon("timer")}0–100</span><span class="spec__value">${v.accel_best}<small>s</small></span></div>
      </div>
      <div class="vehicle-card__footer">
        <button type="button" class="compare-toggle" aria-pressed="${selected}" data-compare-toggle="${esc(v.id)}"
                aria-label="${selected ? "Remove" : "Add"} ${esc(v.name)} ${selected ? "from" : "to"} comparison">
          ${icon(selected ? "check" : "plus")}<span>Compare</span>
        </button>
        <span class="link-arrow">Configure ${icon("arrow-right")}</span>
      </div>
    </div>
  </article>`;
}

function render() {
  const results = $("[data-results]");
  const empty = $("[data-empty]");
  const n = vehicles.length;
  $("[data-result-count]").innerHTML = `<strong>${n}</strong> ${n === 1 ? "model" : "models"} found`;
  empty.hidden = n > 0;
  results.hidden = n === 0;
  results.innerHTML = vehicles.map(cardTemplate).join("");
  results.setAttribute("data-stagger", "");
  observeReveals(results);
  fadeInImages(results);
}

/* ------------------------------------------------------------ compare ---- */
function loadCompare() {
  try { compare = JSON.parse(localStorage.getItem(COMPARE_KEY) || "[]").filter((id) => names[id]).slice(0, MAX_COMPARE); }
  catch { compare = []; }
}

function saveCompare() {
  try { localStorage.setItem(COMPARE_KEY, JSON.stringify(compare)); } catch { /* ignore */ }
}

function toggleCompare(id) {
  if (compare.includes(id)) compare = compare.filter((x) => x !== id);
  else if (compare.length >= MAX_COMPARE) {
    toast(`You can compare up to ${MAX_COMPARE} models. Remove one first.`, { type: "error" });
    return;
  } else compare.push(id);
  saveCompare();
  renderCompare();
}

function renderCompare() {
  const tray = $("[data-compare-tray]");
  tray.classList.toggle("is-visible", compare.length > 0);
  document.body.classList.toggle("has-compare-tray", compare.length > 0);
  $("[data-compare-count]").textContent = String(compare.length);
  $("[data-compare-list]").innerHTML = compare.map((id) => `
    <li>${esc(names[id])}
      <button type="button" data-compare-remove="${esc(id)}" aria-label="Remove ${esc(names[id])} from comparison">${icon("x")}</button>
    </li>`).join("");
  const go = $("[data-compare-go]");
  go.href = `/compare?ids=${compare.join(",")}`;
  go.classList.toggle("is-disabled", compare.length < 2);
  go.setAttribute("aria-disabled", String(compare.length < 2));

  $$("[data-compare-toggle]").forEach((btn) => {
    const id = btn.dataset.compareToggle;
    const on = compare.includes(id);
    btn.setAttribute("aria-pressed", String(on));
    btn.setAttribute("aria-label", `${on ? "Remove" : "Add"} ${names[id]} ${on ? "from" : "to"} comparison`);
    btn.querySelector("use").setAttribute("href", `#i-${on ? "check" : "plus"}`);
  });
}

/* ------------------------------------------------------- mobile sheet ---- */
function setFiltersOpen(open) {
  $("[data-filters]").classList.toggle("is-open", open);
  $("[data-filters-backdrop]").classList.toggle("is-open", open);
  document.body.classList.toggle("is-locked", open);
  $("[data-filters-open]").setAttribute("aria-expanded", String(open));
  if (open) $(".filters__close").focus();
  else $("[data-filters-open]").focus();
}

/* --------------------------------------------------------------- init ---- */
export async function init() {
  try {
    const meta = await api("/api/vehicles");
    meta.vehicles.forEach((v) => { names[v.id] = v.name; });
  } catch { /* names fall back to ids */ }
  loadCompare();
  applyStateToControls(readState());

  const debounced = debounce(refresh, 220);
  $("[data-filters]").addEventListener("input", () => { updateRangeOutputs(); debounced(); });
  $("[data-filters]").addEventListener("change", debounced);
  $('[data-filter="q"]').addEventListener("input", debounced);
  $('[data-filter="sort"]').addEventListener("change", refresh);

  $$("[data-filter-reset]").forEach((b) => b.addEventListener("click", () => {
    applyStateToControls({ ...DEFAULTS });
    refresh();
  }));

  $("[data-results]").addEventListener("click", (e) => {
    const btn = e.target.closest("[data-compare-toggle]");
    if (btn) { e.preventDefault(); toggleCompare(btn.dataset.compareToggle); }
  });
  $("[data-compare-list]").addEventListener("click", (e) => {
    const btn = e.target.closest("[data-compare-remove]");
    if (btn) toggleCompare(btn.dataset.compareRemove);
  });
  $("[data-compare-clear]").addEventListener("click", () => { compare = []; saveCompare(); renderCompare(); });
  $("[data-compare-go]").addEventListener("click", (e) => {
    if (compare.length < 2) { e.preventDefault(); toast("Select at least two models to compare.", { type: "error" }); }
  });

  $("[data-filters-open]").addEventListener("click", () => setFiltersOpen(true));
  $$("[data-filters-close]").forEach((b) => b.addEventListener("click", () => {
    if ($("[data-filters]").classList.contains("is-open")) setFiltersOpen(false);
  }));
  $("[data-filters-backdrop]").addEventListener("click", () => setFiltersOpen(false));
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && $("[data-filters]").classList.contains("is-open")) setFiltersOpen(false);
  });

  renderCompare();
  await refresh();
}
