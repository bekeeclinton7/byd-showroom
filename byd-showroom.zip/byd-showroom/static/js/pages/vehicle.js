/**
 * pages/vehicle.js — Vehicle detail page: viewer + configurator + gallery.
 * The vehicle record is embedded in the page as JSON (no extra request).
 */
import { Viewer } from "../viewer.js";
import { Configurator } from "../configurator.js";
import { Lightbox } from "../lightbox.js";

export function init() {
  const vehicle = JSON.parse(document.getElementById("vehicle-data").textContent);
  const lightbox = new Lightbox(document.querySelector("[data-lightbox]"), vehicle.gallery);

  const viewer = new Viewer(document.querySelector("[data-viewer]"), vehicle, {
    onExpand: (src, alt) => lightbox.open(0, { src, caption: alt }),
  });

  new Configurator(document.querySelector("[data-configurator]"), vehicle, {
    onColour: (colour, opts) => viewer.setColour(colour, opts),
    onInterior: (interior, opts) => viewer.setInterior(interior, opts),
  });

  document.querySelector("[data-gallery]")?.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-lightbox-index]");
    if (btn) lightbox.open(Number(btn.dataset.lightboxIndex));
  });
}
