/** pages/confirmation.js — Copy the order reference and print the summary. */
import { toast } from "../toast.js";
import { icon } from "../icons.js";
import { applySimulatedColours } from "../configurator.js";

export function init() {
  applySimulatedColours();
  document.querySelectorAll("[data-copy]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const text = btn.dataset.copy;
      try {
        await navigator.clipboard.writeText(text);
      } catch {
        // Fallback for browsers/iframes without clipboard permission.
        const ta = Object.assign(document.createElement("textarea"), { value: text });
        ta.setAttribute("readonly", "");
        ta.style.position = "fixed";
        ta.style.opacity = "0";
        document.body.appendChild(ta);
        ta.select();
        const ok = document.execCommand("copy");
        ta.remove();
        if (!ok) { toast("Couldn't copy. Select the reference and copy it manually.", { type: "error" }); return; }
      }
      const original = btn.innerHTML;
      btn.innerHTML = `${icon("check", "icon--sm")} Copied`;
      toast("Order reference copied.");
      setTimeout(() => { btn.innerHTML = original; }, 1800);
    });
  });
  document.querySelectorAll("[data-print]").forEach((btn) => btn.addEventListener("click", () => window.print()));
}
