/**
 * pages/cart.js — Pre-order review, tax estimate, promo codes and checkout.
 *
 * All money values come from the server summary (see app.py summarise());
 * this module only renders them. Client-side validation mirrors the server
 * rules for instant feedback, but the server re-validates everything and its
 * field errors are mapped back onto the form.
 */
import { api } from "../api.js";
import { cad, esc } from "../format.js";
import { icon } from "../icons.js";
import { onCart, updateQty, removeLine, updateSettings, getCart } from "../cart.js";
import { toast } from "../toast.js";
import { prefersReducedMotion } from "../motion.js";
import { applySimulatedColours } from "../configurator.js";

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[A-Za-z]{2,}$/;
const PHONE_RE = /^[0-9+()\-.\s]{7,20}$/;

let dealers = [];
let renderedLineIds = new Set();
let firstRender = true;

/* ------------------------------------------------------------ line items */
function lineTemplate(it, limits, entering) {
  const canAdd = it.qty < limits.per_line && getCart().count < limits.per_order;
  return `
  <li class="line-item${entering ? " is-entering" : ""}" data-line="${esc(it.line_id)}">
    <div class="line-item__img"><img src="${esc(it.image)}" alt="${esc(it.name)} in ${esc(it.colour)}${it.colour_simulated ? " (colour simulation)" : ""}" loading="lazy"${it.colour_simulated ? ` data-simulate-hex="${esc(it.colour_hex)}"` : ""}></div>
    <div class="line-item__info">
      <h3><a class="link-plain" href="/vehicle/${esc(it.vehicle_id)}?trim=${esc(it.trim_id)}&amp;colour=${esc(it.colour_id)}&amp;interior=${esc(it.interior_id)}">${esc(it.name)}</a></h3>
      <p>${esc(it.trim)} &middot; ${esc(it.colour)}${it.colour_simulated ? ' <span class="subtle">(colour simulation)</span>' : ""}</p>
      <p>${esc(it.interior)}</p>
      <div class="line-item__tags">
        <span class="badge badge--soft-red">${icon("tag")}Save ${cad(it.unit_discount)} each</span>
        <span class="badge badge--outline">${icon("calendar")}${esc(it.delivery)}</span>
      </div>
      <div class="line-item__actions">
        <div class="stepper" role="group" aria-label="Quantity for ${esc(it.name)}">
          <button type="button" data-qty="-1" aria-label="Decrease quantity"${it.qty <= 1 ? " disabled" : ""}>${icon("minus")}</button>
          <output aria-live="polite">${it.qty}</output>
          <button type="button" data-qty="1" aria-label="Increase quantity"${canAdd ? "" : " disabled"}>${icon("plus")}</button>
        </div>
        <button type="button" class="btn btn--ghost btn--sm" data-remove>${icon("trash", "icon--sm")} Remove</button>
      </div>
    </div>
    <div class="line-item__price">
      <s>${cad(it.unit_msrp * it.qty)}</s>
      <strong>${cad(it.line_total)}</strong>
      <span class="subtle">${cad(it.line_deposit)} deposit</span>
    </div>
  </li>`;
}

function renderItems(cart) {
  const list = $("[data-line-items]");
  const animate = !firstRender && !prefersReducedMotion();
  list.innerHTML = cart.items.map((it) => lineTemplate(it, cart.limits, animate && !renderedLineIds.has(it.line_id))).join("");
  renderedLineIds = new Set(cart.items.map((it) => it.line_id));
  applySimulatedColours(list);
  $("[data-item-count]").textContent = String(cart.count);
}

/* --------------------------------------------------------------- summary */
function renderSummary(cart) {
  const t = cart.totals;
  const set = (key, text) => { const el = $(`[data-t="${key}"]`); if (el) el.textContent = text; };
  set("msrp", cad(t.msrp));
  set("preorder_savings", `−${cad(t.preorder_savings)}`);
  set("promo_savings", `−${cad(t.promo_savings)}`);
  set("subtotal", cad(t.subtotal));
  set("estimated_total", cad(t.estimated_total, true));
  set("due_today", cad(t.due_today));
  $("[data-submit-due]").textContent = cad(t.due_today);

  $("[data-promo-row]").hidden = !cart.promo;
  if (cart.promo) $("[data-promo-label]").textContent = `Promo ${cart.promo.code}`;

  $("[data-tax-rows]").innerHTML = t.taxes.map((tax) =>
    `<div class="summary__row"><dt>${esc(tax.label)}</dt><dd>${cad(tax.amount, true)}</dd></div>`).join("");

  // Keep both province selects in sync with the server.
  $("[data-summary-province]").value = cart.province;
  const formProvince = $("[data-province-select]");
  if (!formProvince.dataset.touched) {
    formProvince.value = cart.province;
    renderDealers(cart.province);
  }

  const msg = $("[data-promo-msg]");
  if (cart.promo && !msg.classList.contains("is-error")) {
    msg.className = "promo__msg is-success";
    msg.innerHTML = `${esc(cart.promo.label)} applied. <button type="button" data-promo-remove>Remove</button>`;
  }
}

function render(cart) {
  $("[data-checkout-loading]").hidden = true;
  const empty = cart.items.length === 0;
  $("[data-checkout-empty]").hidden = !empty;
  $("[data-checkout]").hidden = empty;
  if (!empty) {
    renderItems(cart);
    renderSummary(cart);
  }
  firstRender = false;
}

/* --------------------------------------------------------------- dealers */
function renderDealers(province) {
  const select = $("[data-dealer-select]");
  const prev = select.value;
  const options = dealers.filter((d) => d.province === province || d.province === "*");
  const local = options.filter((d) => d.province !== "*");
  select.innerHTML =
    (local.length ? "" : '<option value="" disabled>No showroom in this province yet</option>') +
    options.map((d) => `<option value="${esc(d.id)}">${esc(d.name)}</option>`).join("");
  select.value = options.some((d) => d.id === prev) ? prev : options[0].id;
}

/* ------------------------------------------------------------ validation */
function setFieldError(field, message) {
  const wrap = $(`[data-field="${field}"]`);
  if (!wrap) return;
  const input = wrap.querySelector("input, select");
  wrap.classList.toggle("has-error", Boolean(message));
  $(`#e-${field}`).textContent = message || "";
  if (message) {
    input.setAttribute("aria-invalid", "true");
    input.setAttribute("aria-describedby", `e-${field}`);
  } else {
    input.removeAttribute("aria-invalid");
  }
}

function validate(data) {
  const errors = {};
  if (data.name.length < 2 || data.name.length > 80) errors.name = "Enter your full name.";
  if (!EMAIL_RE.test(data.email)) errors.email = "Enter a valid email address.";
  if (data.phone && !PHONE_RE.test(data.phone)) errors.phone = "Enter a valid phone number or leave it blank.";
  if (!data.province) errors.province = "Choose your province or territory.";
  if (!data.dealer) errors.dealer = "Choose a delivery location.";
  if (!data.consent) errors.consent = "Please accept the pre-order terms.";
  return errors;
}

function formData(form) {
  return {
    name: form.name.value.trim(),
    email: form.email.value.trim(),
    phone: form.phone.value.trim(),
    province: form.province.value,
    dealer: form.dealer.value,
    consent: form.consent.checked,
  };
}

/* ------------------------------------------------------------------ init */
export function init() {
  dealers = JSON.parse($("#market-data").textContent).dealers;
  onCart(render);

  // Quantity + remove (event delegation on the list).
  $("[data-line-items]").addEventListener("click", async (e) => {
    const row = e.target.closest("[data-line]");
    if (!row) return;
    const id = row.dataset.line;
    const qtyBtn = e.target.closest("[data-qty]");
    const removeBtn = e.target.closest("[data-remove]");
    try {
      if (qtyBtn) {
        const current = Number(row.querySelector("output").textContent);
        qtyBtn.disabled = true;
        await updateQty(id, current + Number(qtyBtn.dataset.qty));
      } else if (removeBtn) {
        removeBtn.disabled = true;
        if (!prefersReducedMotion()) {
          row.classList.add("is-removing");
          await new Promise((r) => setTimeout(r, 260));
        }
        await removeLine(id);
        toast("Vehicle removed from your pre-order.");
      }
    } catch (err) {
      toast(err.message, { type: "error" });
      render(getCart());
    }
  });

  // Tax province in the summary.
  $("[data-summary-province]").addEventListener("change", async (e) => {
    try {
      await updateSettings({ province: e.target.value });
      const formProvince = $("[data-province-select]");
      formProvince.value = e.target.value;
      renderDealers(e.target.value);
    } catch (err) { toast(err.message, { type: "error" }); }
  });

  // Province in the form drives dealer options and the tax estimate.
  $("[data-province-select]").addEventListener("change", async (e) => {
    e.target.dataset.touched = "1";
    renderDealers(e.target.value);
    setFieldError("province", "");
    setFieldError("dealer", "");
    try { await updateSettings({ province: e.target.value }); } catch (err) { toast(err.message, { type: "error" }); }
  });

  // Promo codes (validated server-side).
  const promoForm = $("[data-promo-form]");
  const promoMsg = $("[data-promo-msg]");
  promoForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const code = promoForm.promo.value.trim();
    if (!code) {
      promoMsg.className = "promo__msg is-error";
      promoMsg.textContent = "Enter a promo code.";
      return;
    }
    const btn = promoForm.querySelector("button[type=submit]");
    btn.disabled = true;
    try {
      promoMsg.className = "promo__msg";
      await updateSettings({ promo: code });
      promoForm.promo.value = "";
    } catch (err) {
      promoMsg.className = "promo__msg is-error";
      promoMsg.textContent = err.message;
    } finally { btn.disabled = false; }
  });
  promoMsg.addEventListener("click", async (e) => {
    if (!e.target.closest("[data-promo-remove]")) return;
    try {
      await updateSettings({ promo: "" });
      promoMsg.className = "promo__msg";
      promoMsg.textContent = "Promo code removed.";
    } catch (err) { toast(err.message, { type: "error" }); }
  });

  // Checkout form. Submitted with fetch() to our own server only; the server
  // stores the order and logs it to Google Sheets in the background, so the
  // browser never talks to Google and never leaves this site until the
  // confirmation page.
  const form = $("[data-checkout-form]");
  // One key per checkout attempt: if a response is lost and the customer
  // clicks again, the server returns the original order instead of a duplicate.
  const checkoutKey = newIdempotencyKey();
  let submitting = false;
  const formError = $("[data-form-error]");
  form.addEventListener("input", (e) => {
    const field = e.target.closest("[data-field]");
    if (field && field.classList.contains("has-error")) setFieldError(field.dataset.field, "");
  });
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (submitting) return;
    formError.hidden = true;
    const data = formData(form);
    const errors = validate(data);
    ["name", "email", "phone", "province", "dealer", "consent"].forEach((f) => setFieldError(f, errors[f]));
    const firstError = Object.keys(errors)[0];
    if (firstError) {
      $(`[data-field="${firstError}"] input, [data-field="${firstError}"] select`).focus();
      return;
    }
    const submit = $("[data-submit]");
    submitting = true;
    submit.disabled = true;
    submit.classList.add("is-loading");
    submit.setAttribute("aria-busy", "true");
    try {
      const res = await api("/api/checkout", {
        method: "POST", body: data, headers: { "Idempotency-Key": checkoutKey },
      });
      window.location.assign(safeConfirmationUrl(res));
    } catch (err) {
      submitting = false;
      submit.disabled = false;
      submit.classList.remove("is-loading");
      submit.removeAttribute("aria-busy");
      if (err.field && $(`[data-field="${err.field}"]`)) {
        setFieldError(err.field, err.message);
        $(`[data-field="${err.field}"] input, [data-field="${err.field}"] select`).focus();
      } else {
        formError.querySelector("span").textContent = err.message;
        formError.hidden = false;
      }
    }
  });
}

/** Random key for the Idempotency-Key header (crypto.randomUUID needs a secure context). */
function newIdempotencyKey() {
  if (window.crypto && typeof window.crypto.randomUUID === "function") return window.crypto.randomUUID();
  const bytes = new Uint8Array(16);
  window.crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}

/** Only ever navigate to our own confirmation page. */
function safeConfirmationUrl(res) {
  const url = new URL(res.redirect || "", window.location.origin);
  if (url.origin === window.location.origin && url.pathname.startsWith("/confirmation/")) return url.pathname;
  return `/confirmation/${encodeURIComponent(res.ref)}`;
}
