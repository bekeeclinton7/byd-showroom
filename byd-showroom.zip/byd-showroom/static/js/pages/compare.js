/**
 * pages/compare.js — Side-by-side comparison of up to three models.
 * Selection comes from ?ids=a,b,c (shareable) or the showroom's saved
 * selection, and is written back to both on change.
 */
import { api } from "../api.js";
import { cad, esc, number } from "../format.js";
import { icon } from "../icons.js";
import { toast } from "../toast.js";

const COMPARE_KEY = "byd-compare";
const SLOTS = 3;
let catalogue = {};
let selection = [null, null, null];

const max = (list, fn) => Math.max(...list.map(fn));
const min = (list, fn) => Math.min(...list.map(fn));

/* Rows: label, icon, value(v) for display, score(v) for "best" (null = no ranking),
   and whether higher or lower is better. */
const GROUPS = [
  { title: "Overview", rows: [
    { label: "Starting price", icon: "tag", value: (v) => `${cad(v.price_from)}<small>est. MSRP</small>`, score: (v) => v.price_from, better: "low" },
    { label: "Pre-order saving", icon: "percent", value: (v) => cad(v.preorder.discount), score: (v) => v.preorder.discount, better: "high" },
    { label: "Body type", icon: "car", value: (v) => esc(v.body) },
    { label: "Seats", icon: "users", value: (v) => v.seats, score: (v) => v.seats, better: "high" },
    { label: "Est. delivery", icon: "calendar", value: (v) => esc(v.delivery) },
    { label: "Trims", icon: "layers", value: (v) => v.trims.map((t) => esc(t.name)).join(", ") },
  ] },
  { title: "Range & battery", rows: [
    { label: "Max range (WLTP)", icon: "route", value: (v) => `${v.range_max} km`, score: (v) => v.range_max, better: "high" },
    { label: "Largest battery", icon: "battery", value: (v) => `${v.battery_max} kWh`, score: (v) => v.battery_max, better: "high" },
  ] },
  { title: "Performance", rows: [
    { label: "Max power", icon: "zap", value: (v) => `${v.power_max} hp`, score: (v) => v.power_max, better: "high" },
    { label: "Max torque", icon: "activity", value: (v) => `${max(v.trims, (t) => t.spec.torque_nm)} Nm`, score: (v) => max(v.trims, (t) => t.spec.torque_nm), better: "high" },
    { label: "0–100 km/h (best)", icon: "timer", value: (v) => `${v.accel_best} s`, score: (v) => v.accel_best, better: "low" },
    { label: "Drive", icon: "move", value: (v) => [...new Set(v.trims.map((t) => t.spec.drive))].join(" / ") },
  ] },
  { title: "Charging", rows: [
    { label: "Peak DC charging", icon: "plug", value: (v) => `${v.dc_max} kW`, score: (v) => v.dc_max, better: "high" },
    { label: "DC fast charge", icon: "clock", value: (v) => esc(v.trims[v.trims.length - 1].spec.dc_time) },
    { label: "AC on-board", icon: "zap", value: (v) => `${max(v.trims, (t) => t.spec.ac_kw)} kW` },
  ] },
  { title: "Dimensions", rows: [
    { label: "Length", icon: "ruler", value: (v) => `${number(v.dimensions.length)} mm` },
    { label: "Width", icon: "ruler", value: (v) => `${number(v.dimensions.width)} mm` },
    { label: "Height", icon: "ruler", value: (v) => `${number(v.dimensions.height)} mm` },
    { label: "Wheelbase", icon: "ruler", value: (v) => `${number(v.dimensions.wheelbase)} mm`, score: (v) => v.dimensions.wheelbase, better: "high" },
    { label: "Cargo (rear)", icon: "bag", value: (v) => `${v.cargo_l} L`, score: (v) => v.cargo_l, better: "high" },
  ] },
  { title: "Ownership", rows: [
    { label: "Warranty", icon: "shield", value: (v) => esc(v.warranty) },
  ] },
];

function readInitial() {
  const fromUrl = (new URLSearchParams(location.search).get("ids") || "").split(",").filter(Boolean);
  let ids = fromUrl;
  if (!ids.length) {
    try { ids = JSON.parse(localStorage.getItem(COMPARE_KEY) || "[]"); } catch { ids = []; }
  }
  const valid = [...new Set(ids)].filter((id) => catalogue[id]).slice(0, SLOTS);
  if (fromUrl.length && valid.length < fromUrl.length) toast("Some models in the link weren't recognised.", { type: "error" });
  return [0, 1, 2].map((i) => valid[i] || null);
}

function persist() {
  const ids = selection.filter(Boolean);
  try { localStorage.setItem(COMPARE_KEY, JSON.stringify(ids)); } catch { /* ignore */ }
  const url = new URL(location.href);
  if (ids.length) url.searchParams.set("ids", ids.join(","));
  else url.searchParams.delete("ids");
  history.replaceState(null, "", url);
}

function slotCard(v, i) {
  if (!v) {
    return `<div class="compare-slot__empty">
      <span class="empty__icon">${icon("plus", "icon--lg")}</span>
      <span class="subtle">Choose a model</span></div>`;
  }
  return `
    <button type="button" class="icon-btn compare-slot__remove" data-slot-remove="${i}" aria-label="Remove ${esc(v.name)} from comparison">${icon("x")}</button>
    <div class="compare-slot__media"><img src="${esc(v.card_image)}" alt="${esc(v.full_name)} in ${esc(v.colours[0].name)}" loading="lazy"></div>
    <div class="compare-slot__body">
      <span class="badge badge--dark">${esc(v.status)}</span>
      <h2>${esc(v.full_name)}</h2>
      <p class="subtle">${esc(v.tagline)}</p>
      <a class="btn btn--outline btn--sm" href="/vehicle/${esc(v.id)}">Configure ${icon("arrow-right", "icon-arrow icon--sm")}</a>
    </div>`;
}

function render() {
  document.querySelectorAll(".compare-slot").forEach((slot, i) => {
    const v = selection[i] ? catalogue[selection[i]] : null;
    slot.querySelector("[data-slot-select]").value = selection[i] || "";
    // Disable models already chosen in another slot.
    slot.querySelectorAll("option[value]").forEach((opt) => {
      opt.disabled = Boolean(opt.value) && selection.includes(opt.value) && selection[i] !== opt.value;
    });
    slot.querySelector("[data-slot-card]").innerHTML = slotCard(v, i);
  });

  const chosen = selection.map((id) => (id ? catalogue[id] : null));
  const filled = chosen.filter(Boolean);
  const rank = filled.length >= 2;
  const table = document.querySelector("[data-compare-table]");
  const thead = table.tHead;
  const tbody = table.tBodies[0];

  if (!filled.length) {
    thead.innerHTML = "";
    tbody.innerHTML = `<tr><td colspan="4"><div class="empty">
      <span class="empty__icon">${icon("compare", "icon--xl")}</span>
      <h2>Nothing to compare yet</h2>
      <p>Choose models above, or pick them in the showroom.</p>
      <a class="btn btn--outline" href="/showroom">Open showroom</a></div></td></tr>`;
    return;
  }

  const head = `<tr><th scope="col"><span class="visually-hidden">Specification</span></th>${chosen.map((v) =>
    `<th scope="col">${v ? esc(v.name) : '<span class="subtle">Empty</span>'}</th>`).join("")}</tr>`;

  thead.innerHTML = head;
  tbody.innerHTML = GROUPS.map((g) => {
    const rows = g.rows.map((r) => {
      let best = null;
      if (rank && r.score) best = r.better === "high" ? max(filled, r.score) : min(filled, r.score);
      // Only highlight if the models actually differ.
      const tie = rank && r.score && filled.every((v) => r.score(v) === best);
      return `<tr><th scope="row">${icon(r.icon)}${r.label}</th>${chosen.map((v) => {
        if (!v) return "<td></td>";
        const isBest = best !== null && !tie && r.score(v) === best;
        return `<td${isBest ? ' class="is-best"' : ""}>${r.value(v)}</td>`;
      }).join("")}</tr>`;
    }).join("");
    return `<tr class="group-row"><th colspan="4" scope="colgroup">${g.title}</th></tr>${rows}`;
  }).join("");
}

export async function init() {
  try {
    const data = await api("/api/vehicles?sort=price-asc");
    data.vehicles.forEach((v) => { catalogue[v.id] = v; });
  } catch (err) {
    toast(err.message, { type: "error" });
    return;
  }
  selection = readInitial();
  render();
  persist();

  const slots = document.querySelector("[data-compare-slots]");
  slots.addEventListener("change", (e) => {
    const select = e.target.closest("[data-slot-select]");
    if (!select) return;
    const i = Number(select.closest(".compare-slot").dataset.slot);
    selection[i] = select.value || null;
    persist();
    render();
  });
  slots.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-slot-remove]");
    if (!btn) return;
    const i = Number(btn.dataset.slotRemove);
    selection[i] = null;
    persist();
    render();
    document.getElementById(`slot-${i}`).focus();
  });
}
