/** format.js — Formatting helpers shared by every page. */
const whole = new Intl.NumberFormat("en-CA", { style: "currency", currency: "CAD", maximumFractionDigits: 0 });
const cents = new Intl.NumberFormat("en-CA", { style: "currency", currency: "CAD", minimumFractionDigits: 2, maximumFractionDigits: 2 });
const num = new Intl.NumberFormat("en-CA");

/** Format a number as Canadian dollars. Cents are dropped when zero unless
 *  `withCents` is set (used for taxes and totals so columns line up). */
export function cad(value, withCents = false) {
  const n = Number(value) || 0;
  return Number.isInteger(n) && !withCents ? whole.format(n) : cents.format(n);
}

export function number(value) {
  return num.format(Number(value) || 0);
}

const ESC = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
/** Escape untrusted strings before inserting them into HTML templates. */
export function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, (c) => ESC[c]);
}

export function debounce(fn, wait = 200) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), wait);
  };
}
