/**
 * api.js — Thin fetch wrapper for the Flask API.
 * The cart id is kept in localStorage and sent as X-Cart-Id so the cart works
 * even where third-party cookies are blocked (e.g. embedded previews).
 */
const CART_KEY = "byd-cart-id";

export class ApiError extends Error {
  constructor(message, field = null, status = 0) {
    super(message);
    this.field = field;
    this.status = status;
  }
}

function readCartId() {
  try { return localStorage.getItem(CART_KEY) || ""; } catch { return ""; }
}

function storeCartId(id) {
  try { localStorage.setItem(CART_KEY, id); } catch { /* storage unavailable */ }
}

/**
 * Call a same-origin API endpoint.
 * @param {string} path            relative URL, e.g. "/api/cart"
 * @param {object} [opts]
 * @param {string} [opts.method]   HTTP method (default GET)
 * @param {*}      [opts.body]     JSON-serialisable request body
 * @param {object} [opts.headers]  extra request headers (e.g. Idempotency-Key)
 * @param {number} [opts.timeout]  abort after this many milliseconds (default 30000)
 */
export async function api(path, { method = "GET", body, headers: extra = {}, timeout = 30000 } = {}) {
  const headers = { Accept: "application/json", ...extra };
  const id = readCartId();
  if (id) headers["X-Cart-Id"] = id;
  if (body !== undefined) headers["Content-Type"] = "application/json";

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  let res;
  try {
    res = await fetch(path, {
      method,
      headers,
      credentials: "same-origin",
      body: body !== undefined ? JSON.stringify(body) : undefined,
      signal: controller.signal,
    });
  } catch (err) {
    throw new ApiError(err && err.name === "AbortError"
      ? "The server took too long to respond. Please try again."
      : "Network error. Check your connection and try again.");
  } finally {
    clearTimeout(timer);
  }

  const newId = res.headers.get("X-Cart-Id");
  if (newId && newId !== id) storeCartId(newId);

  let data = null;
  try { data = await res.json(); } catch { /* non-JSON response */ }
  if (!res.ok || (data && data.ok === false)) {
    throw new ApiError((data && data.error) || `Request failed (${res.status})`, data && data.field, res.status);
  }
  return data;
}
