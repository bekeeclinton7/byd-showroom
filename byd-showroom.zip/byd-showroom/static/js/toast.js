/** toast.js — Lightweight, accessible toast notifications. */
import { icon } from "./icons.js";
import { esc } from "./format.js";

export function toast(message, { type = "info", action = null, timeout = 4200 } = {}) {
  const region = document.querySelector("[data-toasts]");
  if (!region) return;
  const el = document.createElement("div");
  el.className = `toast${type === "error" ? " toast--error" : ""}`;
  el.setAttribute("role", type === "error" ? "alert" : "status");
  el.innerHTML = `${icon(type === "error" ? "alert" : "check-circle")}<span>${esc(message)}</span>` +
    (action ? `<a href="${esc(action.href)}">${esc(action.label)}</a>` : "");
  region.appendChild(el);
  const remove = () => {
    el.classList.add("is-leaving");
    el.addEventListener("animationend", () => el.remove(), { once: true });
    setTimeout(() => el.remove(), 400); // fallback when animations are disabled
  };
  setTimeout(remove, timeout);
}
