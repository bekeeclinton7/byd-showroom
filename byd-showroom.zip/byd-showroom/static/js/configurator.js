/**
 * configurator.js — Trim / paint / interior configurator with live pricing.
 *
 * Exports
 *   recolourImage(src, hex)  Option A fallback: recolour a real BYD photo on a
 *                            <canvas> when no official photo exists for a paint.
 *   Configurator             Binds the configurator form, keeps state in the URL,
 *                            updates price + spec sheet, verifies the quote with
 *                            the server and adds the build to the pre-order.
 */
import { api } from "./api.js";
import { cad, debounce } from "./format.js";
import { addToCart, openDrawer } from "./cart.js";
import { toast } from "./toast.js";
import { prefersReducedMotion } from "./motion.js";

/* =========================================================================
   Option A — Canvas recolour that preserves highlights and reflections
   =========================================================================
   Strategy
   1. Draw the real photo to an offscreen canvas.
   2. Build a soft "paint mask": pixels whose hue sits in the source paint's
      band (e.g. Han Ocean Blue ≈ 200–250°) and are saturated enough to be
      paint rather than glass, tyres, chrome or the grey studio.
   3. For masked pixels, swap hue/saturation for the target colour and shift
      lightness by the difference between the target and the paint's average,
      keeping each pixel's offset from that average (so reflections, panel
      shading and specular highlights survive).
   4. Blend recoloured and original pixels by mask strength, so edges stay soft.
   Results are cached per (src, hex) as object URLs.                        */

const recolourCache = new Map();

function hexToHsl(hex) {
  const n = parseInt(hex.replace("#", ""), 16);
  return rgbToHsl((n >> 16) & 255, (n >> 8) & 255, n & 255);
}

function rgbToHsl(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const l = (max + min) / 2;
  let h = 0;
  let s = 0;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    if (max === r) h = (g - b) / d + (g < b ? 6 : 0);
    else if (max === g) h = (b - r) / d + 2;
    else h = (r - g) / d + 4;
    h *= 60;
  }
  return [h, s, l];
}

function hue2rgb(p, q, t) {
  if (t < 0) t += 1;
  if (t > 1) t -= 1;
  if (t < 1 / 6) return p + (q - p) * 6 * t;
  if (t < 1 / 2) return q;
  if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
  return p;
}

function hslToRgb(h, s, l) {
  if (s === 0) { const v = l * 255; return [v, v, v]; }
  const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
  const p = 2 * l - q;
  const hk = h / 360;
  return [hue2rgb(p, q, hk + 1 / 3) * 255, hue2rgb(p, q, hk) * 255, hue2rgb(p, q, hk - 1 / 3) * 255];
}

const smoothstep = (a, b, x) => {
  const t = Math.min(1, Math.max(0, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
};

function hueDistance(a, b) {
  const d = Math.abs(a - b) % 360;
  return d > 180 ? 360 - d : d;
}

function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.decoding = "async";
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error(`Could not load ${src}`));
    img.src = src;
  });
}

/**
 * Recolour the body paint of a real photo.
 * @param {string} src        same-origin image URL (served via /img proxy)
 * @param {string} targetHex  target paint colour
 * @param {object} [opts]
 * @param {number} [opts.sourceHue=222]  centre of the source paint's hue band
 * @param {number} [opts.band=34]        half-width of the band in degrees
 * @returns {Promise<string>} object URL of the recoloured image
 */
export async function recolourImage(src, targetHex, { sourceHue = 222, band = 34 } = {}) {
  const key = `${src}|${targetHex}`;
  if (recolourCache.has(key)) return recolourCache.get(key);

  const job = (async () => {
    const img = await loadImage(src);
    const w = Math.min(img.naturalWidth, 1600);
    const h = Math.round(img.naturalHeight * (w / img.naturalWidth));
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    ctx.drawImage(img, 0, 0, w, h);
    const data = ctx.getImageData(0, 0, w, h);
    const px = data.data;
    const count = w * h;

    // Pass 1 — paint mask + average lightness/saturation of the paint.
    const mask = new Float32Array(count);
    const lightness = new Float32Array(count);
    const sat = new Float32Array(count);
    const hist = new Float32Array(256); // lightness histogram of paint pixels
    let sumL = 0, sumS = 0, sumW = 0;
    for (let i = 0, p = 0; i < count; i++, p += 4) {
      const [hh, ss, ll] = rgbToHsl(px[p], px[p + 1], px[p + 2]);
      lightness[i] = ll;
      sat[i] = ss;
      const hueW = 1 - smoothstep(band * 0.6, band, hueDistance(hh, sourceHue));
      const satW = smoothstep(0.16, 0.34, ss);
      const lumW = smoothstep(0.04, 0.1, ll) * (1 - smoothstep(0.86, 0.96, ll));
      const m = hueW * satW * lumW;
      mask[i] = m;
      if (m > 0.5) { sumL += ll * m; sumS += ss * m; sumW += m; hist[Math.min(255, (ll * 255) | 0)] += m; }
    }
    if (sumW === 0) return src; // nothing to recolour: fall back to the original
    const refL = sumL / sumW;
    const refS = sumS / sumW;
    // Paint lightness range (5th–97th percentile) for the light-paint mapping.
    const percentile = (q) => {
      let acc = 0;
      for (let k = 0; k < 256; k++) { acc += hist[k]; if (acc >= sumW * q) return k / 255; }
      return 1;
    };
    const lo = percentile(0.05);
    const hi = Math.max(lo + 0.05, percentile(0.97));

    // Pass 2 — map paint pixels to the target colour.
    const [tH, tS, tL] = hexToHsl(targetHex);
    // Dark/saturated targets: shift lightness, keeping each pixel's offset from
    // the paint average (dark targets keep more contrast).
    // Light targets (white, silver): stretch the paint's own lightness range
    // onto grey-to-white, which keeps panel shading natural instead of blotchy.
    const light = tL > 0.6;
    const contrast = tL < 0.2 ? 0.9 : 0.8;
    const floorL = Math.max(0.5, tL - 0.38);
    const ceilL = Math.min(0.97, tL + 0.06);
    for (let i = 0, p = 0; i < count; i++, p += 4) {
      const m = mask[i];
      if (m <= 0.01) continue;
      let l;
      let s;
      if (light) {
        const t = Math.min(1, Math.max(0, (lightness[i] - lo) / (hi - lo)));
        l = floorL + Math.pow(t, 0.6) * (ceilL - floorL);
        s = tS;
      } else {
        l = Math.min(0.98, Math.max(0.02, tL + (lightness[i] - refL) * contrast));
        // Keep each pixel's saturation relative to the paint average (shading).
        s = Math.min(1, tS * Math.min(1.3, Math.max(0.5, sat[i] / refS)));
      }
      const [r, g, b] = hslToRgb(tH, s, l);
      px[p] = px[p] + (r - px[p]) * m;
      px[p + 1] = px[p + 1] + (g - px[p + 1]) * m;
      px[p + 2] = px[p + 2] + (b - px[p + 2]) * m;
    }
    ctx.putImageData(data, 0, 0);
    const blob = await new Promise((res) => canvas.toBlob(res, "image/webp", 0.9));
    return blob ? URL.createObjectURL(blob) : canvas.toDataURL("image/jpeg", 0.9);
  })();

  recolourCache.set(key, job);
  job.catch(() => recolourCache.delete(key));
  return job;
}

/**
 * Swap any <img data-simulate-hex="#rrggbb"> inside root for a canvas
 * recolour of its current (official) photo. Used by the cart drawer and cart
 * page for paints without official photography; the markup around these
 * images labels them as colour simulations.
 */
export function applySimulatedColours(root = document) {
  root.querySelectorAll("img[data-simulate-hex]").forEach(async (img) => {
    const hex = img.dataset.simulateHex;
    img.removeAttribute("data-simulate-hex");
    try { img.src = await recolourImage(img.getAttribute("src"), hex); } catch { /* keep base photo */ }
  });
}

/* =========================================================================
   Configurator
   ========================================================================= */
export class Configurator {
  /**
   * @param {HTMLFormElement} form
   * @param {object} vehicle   full vehicle record from data/vehicles.json
   * @param {object} hooks     { onColour(colour), onInterior(interior), onTrim(trim) }
   */
  constructor(form, vehicle, hooks = {}) {
    this.form = form;
    this.v = vehicle;
    this.hooks = hooks;
    this.state = this.readInitialState();
    this.verify = debounce(() => this.verifyWithServer(), 250);
    this.bind();
    this.applyState({ silent: false, initial: true });
  }

  /* --- State ------------------------------------------------------------- */
  readInitialState() {
    const q = new URLSearchParams(location.search);
    const pick = (list, id) => (list.find((x) => x.id === id) || list[0]).id;
    return {
      trim: pick(this.v.trims, q.get("trim")),
      colour: pick(this.v.colours, q.get("colour")),
      interior: pick(this.v.interiors, q.get("interior")),
    };
  }

  get trim() { return this.v.trims.find((t) => t.id === this.state.trim); }
  get colour() { return this.v.colours.find((c) => c.id === this.state.colour); }
  get interior() { return this.v.interiors.find((i) => i.id === this.state.interior); }

  /** Local price calculation — mirrors app.py price_line() for instant feedback. */
  price() {
    const base = this.trim.price;
    const colour = this.colour.price;
    const interior = this.interior.price;
    const discount = this.v.preorder.discount;
    return { base, colour, interior, discount, total: base + colour + interior - discount };
  }

  /* --- Events ------------------------------------------------------------ */
  bind() {
    this.form.addEventListener("change", (e) => {
      if (e.target.name === "trim") this.set({ trim: e.target.value });
      if (e.target.name === "interior") this.set({ interior: e.target.value });
    });

    // Paint swatches behave as an ARIA radiogroup (roving tabindex + arrows).
    this.swatches = [...this.form.querySelectorAll("[data-colour]")];
    this.swatches.forEach((btn, idx) => {
      btn.addEventListener("click", () => this.set({ colour: btn.dataset.colour }));
      btn.addEventListener("keydown", (e) => {
        const dir = { ArrowRight: 1, ArrowDown: 1, ArrowLeft: -1, ArrowUp: -1 }[e.key];
        if (!dir) return;
        e.preventDefault();
        const next = this.swatches[(idx + dir + this.swatches.length) % this.swatches.length];
        next.focus();
        this.set({ colour: next.dataset.colour });
      });
    });

    this.form.addEventListener("submit", (e) => {
      e.preventDefault();
      this.addToPreorder();
    });
  }

  set(patch) {
    const before = { ...this.state };
    Object.assign(this.state, patch);
    this.applyState({ changed: Object.keys(patch).filter((k) => before[k] !== this.state[k]) });
  }

  /* --- Rendering --------------------------------------------------------- */
  applyState({ changed = [], initial = false } = {}) {
    const { trim, colour, interior } = this;

    // Sync controls (supports state restored from the URL).
    this.form.querySelectorAll('input[name="trim"]').forEach((r) => { r.checked = r.value === trim.id; });
    this.form.querySelectorAll('input[name="interior"]').forEach((r) => { r.checked = r.value === interior.id; });
    this.swatches.forEach((s) => {
      const on = s.dataset.colour === colour.id;
      s.setAttribute("aria-checked", String(on));
      s.tabIndex = on ? 0 : -1;
    });
    this.form.querySelector("[data-colour-name]").textContent =
      colour.name + (colour.source !== "photo" ? " (colour simulation)" : "");
    this.form.querySelector("[data-colour-price]").textContent = colour.price ? `+${cad(colour.price)}` : "Included";

    // Price summary with a subtle tick on the total.
    const p = this.price();
    const set = (k, v) => { const el = this.form.querySelector(`[data-sum="${k}"]`); if (el) el.textContent = v; };
    this.form.querySelector("[data-sum-trim-label]").textContent = trim.name;
    set("base", cad(p.base));
    set("colour", p.colour ? `+${cad(p.colour)}` : cad(0));
    set("interior", p.interior ? `+${cad(p.interior)}` : cad(0));
    set("discount", `−${cad(p.discount)}`);
    const total = this.form.querySelector('[data-sum="total"]');
    if (total.textContent !== cad(p.total)) {
      total.textContent = cad(p.total);
      if (!initial && !prefersReducedMotion()) {
        total.classList.remove("tick"); void total.offsetWidth; total.classList.add("tick");
      }
    }

    if (changed.includes("trim") || initial) this.updateSpecs(!initial);
    if (changed.includes("colour") || initial) this.hooks.onColour?.(colour, { initial });
    if (changed.includes("interior") || initial) this.hooks.onInterior?.(interior, { initial });

    // Keep the build shareable without polluting history.
    const url = new URL(location.href);
    url.searchParams.set("trim", trim.id);
    url.searchParams.set("colour", colour.id);
    url.searchParams.set("interior", interior.id);
    history.replaceState(null, "", url);

    this.form.querySelector("[data-verified]")?.classList.add("is-pending");
    this.verify();
  }

  /** Update every [data-spec] node on the page for the selected trim. */
  updateSpecs(animate) {
    const spec = this.trim.spec;
    document.querySelectorAll("[data-spec]").forEach((el) => {
      const value = spec[el.dataset.spec];
      if (value === undefined || el.textContent === String(value)) return;
      el.textContent = value;
      if (animate && !prefersReducedMotion()) {
        el.classList.remove("spec-flash"); void el.offsetWidth; el.classList.add("spec-flash");
      }
    });
    document.querySelectorAll("[data-spec-trim]").forEach((el) => { el.textContent = this.trim.name; });
  }

  payload(qty = 1) {
    return { vehicle_id: this.v.id, trim_id: this.state.trim, colour_id: this.state.colour, interior_id: this.state.interior, qty };
  }

  /** Ask the server to validate + price the build; reconcile if it differs. */
  async verifyWithServer() {
    const badge = this.form.querySelector("[data-verified]");
    try {
      const { quote } = await api("/api/preorder", { method: "POST", body: this.payload() });
      const total = this.form.querySelector('[data-sum="total"]');
      if (total && cad(quote.unit_price) !== total.textContent) total.textContent = cad(quote.unit_price);
      badge?.classList.remove("is-pending");
    } catch {
      badge?.classList.add("is-pending");
    }
  }

  async addToPreorder() {
    const btn = this.form.querySelector("[data-add-btn]");
    const label = btn.querySelector("span");
    btn.classList.add("is-loading");
    btn.setAttribute("aria-busy", "true");
    const prev = label.textContent;
    label.textContent = "Adding…";
    try {
      await addToCart(this.payload());
      label.textContent = "Added to Pre-Order";
      toast(`${this.v.full_name} ${this.trim.name} reserved in ${this.colour.name}.`, { action: { href: "/cart", label: "Checkout" } });
      openDrawer();
    } catch (err) {
      label.textContent = prev;
      toast(err.message, { type: "error" });
    } finally {
      btn.classList.remove("is-loading");
      btn.removeAttribute("aria-busy");
      setTimeout(() => { label.textContent = prev; }, 1800);
    }
  }
}
