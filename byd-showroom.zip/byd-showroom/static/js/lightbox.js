/**
 * lightbox.js — Accessible full-screen image viewer with captions/credits.
 * Keyboard: ←/→ to navigate, Esc to close. Focus is trapped while open.
 * Swipe left/right on touch devices.
 */
export class Lightbox {
  /** @param {HTMLElement} root  @param {{src:string, caption:string}[]} items */
  constructor(root, items = []) {
    this.root = root;
    this.items = items;
    this.index = 0;
    this.img = root.querySelector("[data-lightbox-img]");
    this.caption = root.querySelector("[data-lightbox-caption]");
    this.count = root.querySelector("[data-lightbox-count]");
    this.onKey = this.onKey.bind(this);

    root.querySelector("[data-lightbox-close]").addEventListener("click", () => this.close());
    root.querySelector("[data-lightbox-prev]").addEventListener("click", () => this.step(-1));
    root.querySelector("[data-lightbox-next]").addEventListener("click", () => this.step(1));
    root.addEventListener("click", (e) => { if (e.target === root || e.target.classList.contains("lightbox__stage")) this.close(); });

    let startX = null;
    root.addEventListener("touchstart", (e) => { startX = e.touches[0].clientX; }, { passive: true });
    root.addEventListener("touchend", (e) => {
      if (startX === null) return;
      const dx = e.changedTouches[0].clientX - startX;
      if (Math.abs(dx) > 50) this.step(dx < 0 ? 1 : -1);
      startX = null;
    });
  }

  /** Open at an index, or open a one-off image (used by the viewer's expand button). */
  open(index = 0, single = null) {
    this.single = single;
    this.index = index;
    this.lastFocus = document.activeElement;
    this.render();
    this.root.classList.add("is-open");
    this.root.setAttribute("aria-hidden", "false");
    document.body.classList.add("is-locked");
    document.addEventListener("keydown", this.onKey);
    setTimeout(() => this.root.querySelector("[data-lightbox-close]").focus(), 50);
  }

  close() {
    this.root.classList.remove("is-open");
    this.root.setAttribute("aria-hidden", "true");
    document.body.classList.remove("is-locked");
    document.removeEventListener("keydown", this.onKey);
    this.lastFocus?.focus?.();
  }

  step(dir) {
    if (this.single || !this.items.length) return;
    this.index = (this.index + dir + this.items.length) % this.items.length;
    this.render();
  }

  render() {
    const item = this.single || this.items[this.index];
    if (!item) return;
    const multi = !this.single && this.items.length > 1;
    this.root.querySelectorAll("[data-lightbox-prev], [data-lightbox-next]").forEach((b) => { b.hidden = !multi; });
    this.count.textContent = multi ? `${this.index + 1} / ${this.items.length}` : "";
    this.img.classList.remove("is-loaded");
    this.img.onload = () => this.img.classList.add("is-loaded");
    this.img.src = item.src;
    this.img.alt = item.caption;
    this.caption.textContent = item.caption;
    if (this.img.complete && this.img.naturalWidth) this.img.classList.add("is-loaded");
  }

  onKey(e) {
    if (e.key === "Escape") this.close();
    else if (e.key === "ArrowRight") this.step(1);
    else if (e.key === "ArrowLeft") this.step(-1);
    else if (e.key === "Tab") {
      const f = [...this.root.querySelectorAll("button:not([hidden])")];
      const i = f.indexOf(document.activeElement);
      if (e.shiftKey && i <= 0) { e.preventDefault(); f[f.length - 1].focus(); }
      else if (!e.shiftKey && i === f.length - 1) { e.preventDefault(); f[0].focus(); }
    }
  }
}
