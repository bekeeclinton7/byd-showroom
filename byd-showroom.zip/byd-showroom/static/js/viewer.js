/**
 * viewer.js — Visual inspection viewer.
 *
 * A "photo sequence" built from real BYD photography:
 *   Exterior (front three-quarter) → Profile → Detail shots → Interior
 * Users move through it with tabs, thumbnails, arrow buttons, ←/→ keys or by
 * dragging / swiping the stage. Each frame can carry hotspot markers
 * (positions are % of the photo, defined in data/vehicles.json) that open a
 * small feature card.
 *
 * Colour handling
 *   - Paint with official photos: the matching photo is shown.
 *   - Paint without photos (source: "simulated"): the base photo is recoloured
 *     on a canvas (Option A, see configurator.js) and labelled "Colour simulation".
 * Interior handling
 *   - Real interior photo: shown as-is.
 *   - No photo for that trim (real: false): Option C — the real base interior
 *     photo is shown with a material swatch legend overlay, labelled "Material preview".
 *
 * Transitions are a crossfade between two stacked <img> layers.
 */
import { icon } from "./icons.js";
import { esc } from "./format.js";
import { recolourImage } from "./configurator.js";

const VIEW_LABELS = { front: "Exterior", profile: "Profile", details: "Detail", interior: "Interior" };

export class Viewer {
  constructor(root, vehicle, { onExpand } = {}) {
    this.root = root;
    this.v = vehicle;
    this.onExpand = onExpand;
    this.stage = root.querySelector("[data-stage]");
    this.frameEl = root.querySelector("[data-frame]");
    this.layers = [...root.querySelectorAll("[data-layer]")];
    this.hotspotLayer = root.querySelector("[data-hotspots]");
    this.card = root.querySelector("[data-hotspot-card]");
    this.legend = root.querySelector("[data-material-legend]");
    this.label = root.querySelector("[data-viewer-label]");
    this.thumbs = root.querySelector("[data-thumbs]");
    this.credit = root.querySelector("[data-viewer-credit]");
    this.hint = root.querySelector("[data-viewer-hint]");
    this.tabs = [...root.querySelectorAll("[data-view]")];
    this.pill = root.querySelector(".segmented__pill");

    // The first colour with real photos is the base for simulated colours.
    this.baseColour = vehicle.colours.find((c) => c.source === "photo");
    this.colour = this.baseColour;
    this.interior = vehicle.interiors[0];
    this.index = 0;
    this.hotspotsOn = true;
    this.token = 0; // guards against out-of-order async loads

    this.buildSequence();
    this.bind();
    this.renderThumbs();
    this.movePill();
  }

  /* --- Sequence ---------------------------------------------------------- */
  buildSequence() {
    const frames = [{ view: "front" }];
    if (this.baseColour.images.length > 1) frames.push({ view: "profile" });
    this.v.details.forEach((src, i) => frames.push({ view: "details", i, src }));
    frames.push({ view: "interior" });
    this.frames = frames;
  }

  get frame() { return this.frames[this.index]; }

  /** Resolve the image URL for a frame given the current colour/interior. */
  async resolve(frame) {
    if (frame.view === "details") return { src: frame.src, photo: true };
    if (frame.view === "interior") return { src: this.interior.photo, photo: true };
    const slot = frame.view === "front" ? 0 : 1;
    if (this.colour.source === "photo") {
      return { src: this.colour.images[slot] || this.colour.images[0], photo: this.v.id === "tang" || this.v.id === "han" };
    }
    const base = this.baseColour.images[slot] || this.baseColour.images[0];
    return { src: await recolourImage(base, this.colour.hex), photo: true, simulated: true };
  }

  /* --- Events ------------------------------------------------------------ */
  bind() {
    this.tabs.forEach((tab) => tab.addEventListener("click", () => {
      this.go(this.frames.findIndex((f) => f.view === tab.dataset.view));
    }));
    // Arrow keys move between tabs (WAI-ARIA tabs pattern).
    this.root.querySelector("[data-view-tabs]").addEventListener("keydown", (e) => {
      const dir = { ArrowRight: 1, ArrowLeft: -1 }[e.key];
      if (!dir) return;
      const i = this.tabs.indexOf(document.activeElement);
      if (i < 0) return;
      e.preventDefault();
      const next = this.tabs[(i + dir + this.tabs.length) % this.tabs.length];
      next.focus();
      next.click();
    });

    this.root.querySelector("[data-viewer-prev]").addEventListener("click", () => this.step(-1));
    this.root.querySelector("[data-viewer-next]").addEventListener("click", () => this.step(1));
    this.root.querySelector("[data-viewer-expand]").addEventListener("click", () => this.onExpand?.(this.currentSrc, this.currentAlt));
    const hsToggle = this.root.querySelector("[data-hotspot-toggle]");
    hsToggle.addEventListener("click", () => {
      this.hotspotsOn = !this.hotspotsOn;
      hsToggle.setAttribute("aria-pressed", String(this.hotspotsOn));
      this.hotspotLayer.classList.toggle("is-hidden", !this.hotspotsOn);
      if (!this.hotspotsOn) this.closeCard();
    });

    this.stage.addEventListener("keydown", (e) => {
      if (e.target !== this.stage) return;
      if (e.key === "ArrowRight") { e.preventDefault(); this.step(1); }
      if (e.key === "ArrowLeft") { e.preventDefault(); this.step(-1); }
    });
    document.addEventListener("keydown", (e) => { if (e.key === "Escape") this.closeCard(); });
    document.addEventListener("click", (e) => {
      if (!this.card.hidden && !e.target.closest(".hotspot") && !e.target.closest("[data-hotspot-card]")) this.closeCard();
    });

    // Drag / swipe through the sequence: one frame per 70px of travel.
    let startX = null;
    let stepped = 0;
    this.stage.addEventListener("pointerdown", (e) => {
      if (e.target.closest("button")) return;
      startX = e.clientX;
      stepped = 0;
      this.stage.setPointerCapture(e.pointerId);
    });
    this.stage.addEventListener("pointermove", (e) => {
      if (startX === null) return;
      const travel = Math.trunc((startX - e.clientX) / 70);
      if (travel !== stepped) {
        this.step(travel > stepped ? 1 : -1, { wrap: false });
        stepped = travel;
        this.hideHint();
      }
    });
    const end = () => { startX = null; };
    this.stage.addEventListener("pointerup", end);
    this.stage.addEventListener("pointercancel", end);

    window.addEventListener("resize", () => { this.movePill(); this.closeCard(); });
  }

  hideHint() { this.hint?.classList.add("is-hidden"); }

  step(dir, { wrap = true } = {}) {
    let next = this.index + dir;
    if (wrap) next = (next + this.frames.length) % this.frames.length;
    else next = Math.max(0, Math.min(this.frames.length - 1, next));
    if (next !== this.index) this.go(next);
  }

  go(index) {
    if (index < 0) return;
    this.index = index;
    this.hideHint();
    this.show();
  }

  /* --- Public API used by the configurator -------------------------------- */
  setColour(colour, { initial = false } = {}) {
    this.colour = colour;
    // When a paint is picked while looking at the cabin, jump back outside.
    if (!initial && ["details", "interior"].includes(this.frame.view)) this.index = 0;
    this.show({ initial });
  }

  setInterior(interior, { initial = false } = {}) {
    this.interior = interior;
    if (initial) return;
    this.index = this.frames.findIndex((f) => f.view === "interior");
    this.show();
  }

  /* --- Rendering --------------------------------------------------------- */
  async show({ initial = false } = {}) {
    const token = ++this.token;
    const frame = this.frame;
    this.closeCard();
    this.updateTabs();

    let resolved;
    try {
      resolved = await this.resolve(frame);
    } catch {
      resolved = { src: this.baseColour.images[0], photo: false };
    }
    const img = new Image();
    img.src = resolved.src;
    try { await img.decode(); } catch { /* broken image: the fallback SVG still decodes */ }
    if (token !== this.token) return; // a newer request won

    // Match the frame to the photo's aspect ratio so hotspots line up.
    if (img.naturalWidth) this.frameEl.style.setProperty("--ar", (img.naturalWidth / img.naturalHeight).toFixed(4));
    this.stage.classList.toggle("is-photo", Boolean(resolved.photo));

    // Crossfade: load into the hidden layer, then swap.
    const [active, idle] = this.layers[0].classList.contains("is-active") ? this.layers : [this.layers[1], this.layers[0]];
    const alt = this.altText(frame);
    if (initial && active.getAttribute("src") === resolved.src) {
      active.alt = alt;
    } else {
      idle.src = resolved.src;
      idle.alt = alt;
      idle.removeAttribute("aria-hidden");
      active.alt = "";
      active.setAttribute("aria-hidden", "true");
      idle.classList.add("is-active");
      active.classList.remove("is-active");
    }
    this.currentSrc = resolved.src;
    this.currentAlt = alt;

    this.renderLabel(frame, resolved);
    this.renderLegend(frame);
    this.renderHotspots(frame);
    this.updateThumbs();
    this.credit.textContent = resolved.simulated
      ? "Colour simulation based on official BYD photo"
      : frame.view === "interior" && !this.interior.real
        ? "Photo: BYD Auto (standard interior shown)"
        : "Photo: BYD Auto (official)";
  }

  altText(frame) {
    const name = this.v.full_name;
    if (frame.view === "interior") return `${name} interior${this.interior.real ? `, ${this.interior.name}` : ""}`;
    if (frame.view === "details") return `${name} exterior detail ${frame.i + 1}`;
    const angle = frame.view === "front" ? "front three-quarter view" : "side profile";
    return `${name} in ${this.colour.name}, ${angle}${this.colour.source !== "photo" ? " (colour simulation)" : ""}`;
  }

  renderLabel(frame, resolved) {
    let html = "";
    if (resolved.simulated) html = `${icon("palette")} Colour simulation`;
    else if (frame.view === "interior" && !this.interior.real) html = `${icon("layers")} Material preview`;
    this.label.hidden = !html;
    this.label.innerHTML = html;
  }

  /** Option C — swatch legend over the real base interior photo. */
  renderLegend(frame) {
    const show = frame.view === "interior" && !this.interior.real;
    this.legend.hidden = !show;
    if (!show) return;
    this.hideHint(); // the legend occupies the bottom of the stage
    const base = this.v.interiors.find((i) => i.real);
    this.legend.innerHTML = `
      <span class="material-legend__title">${icon("layers")} ${esc(this.interior.name)}</span>
      ${this.interior.materials.map((m) => `
        <span class="material-legend__row">
          <span class="material-legend__chip" style="background:${esc(m.hex)}"></span>
          <span class="material-legend__part">${esc(m.part)}</span>
          <span class="material-legend__name">${esc(m.name)}</span>
        </span>`).join("")}
      <p class="material-legend__note">Photo shows ${esc(base ? base.name : "standard")} interior. Swatches show your selected materials.</p>`;
  }

  renderHotspots(frame) {
    const spots = (frame.view !== "details" && this.v.hotspots[frame.view]) || [];
    this.hotspotLayer.innerHTML = spots.map((h, i) => `
      <button type="button" class="hotspot" style="left:${h.x}%;top:${h.y}%;animation-delay:${150 + i * 80}ms"
              aria-label="Feature: ${esc(h.title)}" aria-expanded="false" data-hotspot="${i}">
        ${icon("plus")}
      </button>`).join("");
    this.hotspotLayer.querySelectorAll("[data-hotspot]").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        const open = btn.getAttribute("aria-expanded") === "true";
        this.closeCard();
        if (!open) this.openCard(btn, spots[Number(btn.dataset.hotspot)]);
      });
    });
  }

  openCard(btn, spot) {
    btn.setAttribute("aria-expanded", "true");
    this.card.innerHTML = `<h3>${icon(spot.icon || "info")} ${esc(spot.title)}</h3><p>${esc(spot.text)}</p>`;
    this.card.hidden = false;
    // Position the card next to the marker, clamped inside the stage.
    const stage = this.stage.getBoundingClientRect();
    const b = btn.getBoundingClientRect();
    const cw = this.card.offsetWidth;
    const ch = this.card.offsetHeight;
    const cx = b.left - stage.left + b.width / 2;
    const cy = b.top - stage.top + b.height / 2;
    let left = cx + 24;
    if (left + cw > stage.width - 12) left = cx - cw - 24;
    left = Math.max(12, Math.min(left, stage.width - cw - 12));
    const top = Math.max(12, Math.min(cy - ch / 2, stage.height - ch - 12));
    this.card.style.left = `${left}px`;
    this.card.style.top = `${top}px`;
  }

  closeCard() {
    if (!this.card || this.card.hidden) return;
    this.card.hidden = true;
    this.hotspotLayer.querySelectorAll('[aria-expanded="true"]').forEach((b) => b.setAttribute("aria-expanded", "false"));
  }

  /* --- Tabs & thumbnails --------------------------------------------------- */
  updateTabs() {
    this.tabs.forEach((t) => {
      const on = t.dataset.view === this.frame.view;
      t.setAttribute("aria-selected", String(on));
      t.tabIndex = on ? 0 : -1;
    });
    this.movePill();
  }

  /** Slide the segmented-control pill under the selected tab. */
  movePill() {
    const sel = this.tabs.find((t) => t.getAttribute("aria-selected") === "true");
    if (!sel || !this.pill) return;
    this.pill.style.width = `${sel.offsetWidth}px`;
    this.pill.style.transform = `translateX(${sel.offsetLeft}px)`;
  }

  async renderThumbs() {
    this.thumbs.innerHTML = this.frames.map((f, i) => `
      <li><button type="button" data-thumb="${i}" aria-label="Show ${VIEW_LABELS[f.view]}${f.view === "details" ? ` ${f.i + 1}` : ""} view">
        <img alt="" loading="lazy" data-thumb-img="${i}">
      </button></li>`).join("");
    this.thumbs.querySelectorAll("[data-thumb]").forEach((b) => b.addEventListener("click", () => this.go(Number(b.dataset.thumb))));
    await this.refreshThumbImages();
    this.updateThumbs();
  }

  async refreshThumbImages() {
    await Promise.all(this.frames.map(async (f, i) => {
      const img = this.thumbs.querySelector(`[data-thumb-img="${i}"]`);
      try {
        const { src } = await this.resolve(f);
        if (img && img.getAttribute("src") !== src) img.src = src;
      } catch { /* keep previous thumbnail */ }
    }));
  }

  updateThumbs() {
    this.thumbs.querySelectorAll("[data-thumb]").forEach((b) => {
      b.setAttribute("aria-current", String(Number(b.dataset.thumb) === this.index));
    });
    this.refreshThumbImages();
  }
}
