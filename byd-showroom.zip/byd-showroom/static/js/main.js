/**
 * main.js — Entry point loaded on every page.
 * Boots the shared modules (theme, motion, cart) and then lazy-loads the
 * module for the current page based on <body data-page="…">.
 */
import { initTheme } from "./theme.js";
import { initMotion } from "./motion.js";
import { initCart } from "./cart.js";

window.__bydBooted = true;

initTheme();
initMotion();
initCart();

const PAGE_MODULES = {
  showroom: "./pages/showroom.js",
  vehicle: "./pages/vehicle.js",
  compare: "./pages/compare.js",
  cart: "./pages/cart.js",
  confirmation: "./pages/confirmation.js",
};

const page = document.body.dataset.page;
if (PAGE_MODULES[page]) {
  import(PAGE_MODULES[page])
    .then((mod) => mod.init())
    .catch((err) => console.error(`[BYD] Failed to start ${page} page`, err));
}
