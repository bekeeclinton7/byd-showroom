/** icons.js — Reference a symbol from the inline sprite (/static/icons/sprite.svg). */
export function icon(name, cls = "") {
  return `<svg class="icon ${cls}" aria-hidden="true" focusable="false"><use href="#i-${name}"></use></svg>`;
}
