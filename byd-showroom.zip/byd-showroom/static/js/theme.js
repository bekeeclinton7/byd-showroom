/**
 * theme.js — Light / dark theme toggle.
 * The initial theme is applied by an inline script in <head> (no flash);
 * this module wires the toggle button and persists the choice.
 */
const KEY = "byd-theme";

function apply(theme) {
  document.documentElement.setAttribute("data-theme", theme);
  document.querySelectorAll("[data-theme-toggle]").forEach((btn) => {
    btn.setAttribute("aria-label", theme === "dark" ? "Switch to light theme" : "Switch to dark theme");
  });
}

export function initTheme() {
  apply(document.documentElement.getAttribute("data-theme") || "light");
  document.querySelectorAll("[data-theme-toggle]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const next = document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark";
      apply(next);
      try { localStorage.setItem(KEY, next); } catch { /* ignore */ }
    });
  });
}
