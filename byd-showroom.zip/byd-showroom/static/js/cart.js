/**
 * cart.js — Global pre-order cart store + slide-out drawer.
 *
 * The server (SQLite) is the source of truth. Every mutation returns the full,
 * server-priced cart summary, which is broadcast to subscribers (header badge,
 * drawer, cart page) so the UI can never drift from the backend's totals.
 */
import { api } from "./api.js";
import { cad, esc } from "./format.js";
import { icon } from "./icons.js";

let state = null;
const listeners = new Set();

/* ------------------------------------------------------------------- store */
export const getCart = () => state;

/** Subscribe to cart updates. Fires immediately if a cart is already loaded. */
export function onCart(fn) {
  listeners.add(fn);
  if (state) fn(state);
  return () => listeners.delete(fn);
}

export function setCart(summary) {
  const prevCount = state ? state.count : 0;
  state = summary;
  renderBadge(prevCount);
  renderDrawer();
  listeners.forEach((fn) => fn(state));
}

export async function loadCart() {
  setCart(await api("/api/cart"));
  return state;
}

export async function addToCart(config) {
  const summary = await api("/api/cart", { method: "POST", body: config });
  setCart(summary);
  return summary;
}

export async function updateQty(lineId, qty) {
  setCart(await api(`/api/cart/${encodeURIComponent(lineId)}`, { method: "PATCH", body: { qty } }));
  return state;
}

export async function removeLine(lineId) {
  setCart(await api(`/api/cart/${encodeURIComponent(lineId)}`, { method: "DELETE" }));
  return state;
}

/** Update province and/or promo code (validated server-side). */
export async function updateSettings(body) {
  setCart(await api("/api/cart", { method: "PATCH", body }));
  return state;
}

/* ------------------------------------------------------------------- badge */
function renderBadge(prevCount) {
  document.querySelectorAll("[data-cart-count]").forEach((el) => {
    el.textContent = String(state.count);
    el.classList.toggle("has-items", state.count > 0);
    if (state.count > prevCount) {
      el.classList.remove("bump");
      void el.offsetWidth;
      el.classList.add("bump");
    }
  });
  document.querySelectorAll("[data-cart-open]").forEach((btn) => {
    btn.setAttribute("aria-label", `Open pre-order cart, ${state.count} ${state.count === 1 ? "vehicle" : "vehicles"}`);
  });
}

/* ------------------------------------------------------------------ drawer */
const drawer = () => document.getElementById("cart-drawer");
const backdrop = () => document.querySelector("[data-backdrop]");
let lastFocus = null;

function renderDrawer() {
  const body = document.querySelector("[data-drawer-body]");
  const foot = document.querySelector("[data-drawer-foot]");
  if (!body || !state) return;

  if (!state.items.length) {
    body.innerHTML = `
      <div class="empty">
        <span class="empty__icon">${icon("bag", "icon--xl")}</span>
        <h3>Nothing reserved yet</h3>
        <p>Configure a BYD and add it to your pre-order.</p>
        <a class="btn btn--outline" href="/showroom">Browse models</a>
      </div>`;
    foot.hidden = true;
    return;
  }

  body.innerHTML = `<ul>${state.items.map((it, i) => `
    <li class="mini-item" style="--delay:${i * 70}ms">
      <div class="mini-item__img"><img src="${esc(it.image)}" alt="${esc(it.name)} in ${esc(it.colour)}${it.colour_simulated ? " (colour simulation)" : ""}" loading="lazy"${it.colour_simulated ? ` data-simulate-hex="${esc(it.colour_hex)}"` : ""}></div>
      <div>
        <h3>${esc(it.name)}${it.qty > 1 ? ` <span class="subtle">&times; ${it.qty}</span>` : ""}</h3>
        <p>${esc(it.trim)} &middot; ${esc(it.colour)}${it.colour_simulated ? " (simulated)" : ""}</p>
        <p>${esc(it.interior)}</p>
      </div>
      <div class="mini-item__price">
        ${cad(it.line_total)}
        <div><button class="btn btn--ghost btn--sm" type="button" data-drawer-remove="${esc(it.line_id)}" aria-label="Remove ${esc(it.name)}">${icon("trash", "icon--sm")}</button></div>
      </div>
    </li>`).join("")}</ul>`;
  if (state.items.some((it) => it.colour_simulated)) {
    import("./configurator.js").then((m) => m.applySimulatedColours(body));
  }

  foot.hidden = false;
  foot.querySelector("[data-drawer-subtotal]").textContent = cad(state.totals.msrp);
  foot.querySelector("[data-drawer-savings]").textContent = `−${cad(state.totals.preorder_savings + state.totals.promo_savings)}`;
  foot.querySelector("[data-drawer-due]").textContent = cad(state.totals.due_today);
}

function focusables(root) {
  return [...root.querySelectorAll('a[href], button:not([disabled]), input, select, textarea, [tabindex]:not([tabindex="-1"])')]
    .filter((el) => el.offsetParent !== null);
}

function trapFocus(e) {
  if (e.key === "Escape") { closeDrawer(); return; }
  if (e.key !== "Tab") return;
  const items = focusables(drawer());
  if (!items.length) return;
  const first = items[0];
  const last = items[items.length - 1];
  if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
  else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
}

export function openDrawer() {
  const d = drawer();
  if (!d || d.classList.contains("is-open")) return;
  lastFocus = document.activeElement;
  renderDrawer(); // re-render so items animate in sequence
  d.classList.add("is-open");
  d.setAttribute("aria-hidden", "false");
  backdrop().classList.add("is-open");
  document.body.classList.add("is-locked");
  document.querySelectorAll("[data-cart-open]").forEach((b) => b.setAttribute("aria-expanded", "true"));
  d.addEventListener("keydown", trapFocus);
  setTimeout(() => d.querySelector("[data-cart-close]").focus(), 50);
}

export function closeDrawer() {
  const d = drawer();
  if (!d || !d.classList.contains("is-open")) return;
  d.classList.remove("is-open");
  d.setAttribute("aria-hidden", "true");
  backdrop().classList.remove("is-open");
  document.body.classList.remove("is-locked");
  document.querySelectorAll("[data-cart-open]").forEach((b) => b.setAttribute("aria-expanded", "false"));
  d.removeEventListener("keydown", trapFocus);
  if (lastFocus && typeof lastFocus.focus === "function") lastFocus.focus();
}

export function initCart() {
  document.querySelectorAll("[data-cart-open]").forEach((b) => b.addEventListener("click", openDrawer));
  document.querySelector("[data-cart-close]")?.addEventListener("click", closeDrawer);
  backdrop()?.addEventListener("click", closeDrawer);
  document.querySelector("[data-drawer-body]")?.addEventListener("click", async (e) => {
    const btn = e.target.closest("[data-drawer-remove]");
    if (!btn) return;
    btn.disabled = true;
    try { await removeLine(btn.dataset.drawerRemove); }
    catch (err) { btn.disabled = false; (await import("./toast.js")).toast(err.message, { type: "error" }); }
  });
  loadCart().catch(() => {
    const body = document.querySelector("[data-drawer-body]");
    if (body) body.innerHTML = '<p class="subtle">We couldn\'t load your pre-order. Refresh to try again.</p>';
  });
}
