Put your Google service-account JSON key here (Option B), e.g.
`credentials/sheets-logger.json`, then set
`GOOGLE_SERVICE_ACCOUNT_FILE=credentials/sheets-logger.json` in `.env`.

Everything in this folder is git-ignored. Never place keys under `static/`
(that folder is publicly served).
