/**
 * BYD Canada showroom: checkout logger (Google Apps Script web app).
 *
 * Paste this file into Extensions > Apps Script of the spreadsheet that should
 * receive orders, set the Script Property WEBHOOK_SECRET, and deploy it as a
 * Web app (Execute as: Me, Who has access: Anyone). Full steps are in
 * docs/google-sheets-setup.md.
 *
 * Only the Flask server calls this URL, never a browser. Each request is
 * signed with HMAC-SHA256 using the shared secret, so knowing the URL alone is
 * not enough to write to the sheet. Requests older than 5 minutes are refused.
 *
 * Request body (JSON): { ts: "<unix seconds>", data: "<JSON string>", sig: "<hex>" }
 *   sig = HMAC_SHA256(WEBHOOK_SECRET, ts + "." + data)
 *   data = { action: "append", ref, headers: [...], rows: [[...], ...] }
 *        | { action: "ping", headers: [...] }
 * Response (JSON): { ok: true, status: "appended" | "duplicate" | "pong", ... }
 *                | { ok: false, error: "..." }
 */

var SHEET_NAME = 'Pre-orders';
var MAX_SKEW_SECONDS = 300;
var MONEY_HEADERS = ['Deposit Amount', 'Discount Applied', 'Subtotal', 'Tax (GST/PST)', 'Total Amount'];

function doPost(e) {
  try {
    if (!e || !e.postData || !e.postData.contents) return json_({ ok: false, error: 'Empty request' });
    var body = JSON.parse(e.postData.contents);
    var secret = PropertiesService.getScriptProperties().getProperty('WEBHOOK_SECRET');
    if (!secret) return json_({ ok: false, error: 'Script property WEBHOOK_SECRET is not set' });

    var ts = String(body.ts || '');
    var data = String(body.data || '');
    var expected = toHex_(Utilities.computeHmacSha256Signature(ts + '.' + data, secret, Utilities.Charset.UTF_8));
    if (!safeEqual_(expected, String(body.sig || ''))) return json_({ ok: false, error: 'Invalid signature' });
    if (!/^\d+$/.test(ts) || Math.abs(Date.now() / 1000 - Number(ts)) > MAX_SKEW_SECONDS) {
      return json_({ ok: false, error: 'Request expired (check the server clock)' });
    }

    var payload = JSON.parse(data);
    var headers = Array.isArray(payload.headers) ? payload.headers.map(String) : [];
    if (!headers.length) return json_({ ok: false, error: 'Missing headers' });

    var lock = LockService.getScriptLock();
    lock.waitLock(20000); // serialise writers so duplicate checks are reliable
    try {
      var sheet = getSheet_(headers);
      if (payload.action === 'ping') return json_({ ok: true, status: 'pong', sheet: sheet.getName() });
      if (payload.action !== 'append') return json_({ ok: false, error: 'Unknown action' });

      var ref = String(payload.ref || '');
      var rows = payload.rows;
      if (!ref || !Array.isArray(rows) || !rows.length) return json_({ ok: false, error: 'Missing ref or rows' });
      if (refExists_(sheet, ref)) return json_({ ok: true, status: 'duplicate', rows: 0 });

      var width = headers.length;
      var values = rows.map(function (row) {
        var out = [];
        for (var i = 0; i < width; i++) out.push(sanitize_(row[i]));
        return out;
      });
      sheet.getRange(sheet.getLastRow() + 1, 1, values.length, width).setValues(values);
      return json_({ ok: true, status: 'appended', rows: values.length });
    } finally {
      lock.releaseLock();
    }
  } catch (err) {
    return json_({ ok: false, error: String((err && err.message) || err) });
  }
}

/** Visiting the URL in a browser shows that the deployment works, and nothing more. */
function doGet() {
  return json_({ ok: true, service: 'BYD showroom checkout logger', hint: 'POST only' });
}

/** Return the target tab, creating it and its header row if needed. */
function getSheet_(headers) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(SHEET_NAME) || ss.insertSheet(SHEET_NAME);
  var firstRow = sheet.getRange(1, 1, 1, headers.length).getValues()[0];
  var empty = firstRow.every(function (v) { return v === '' || v === null; });
  if (empty) {
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]).setFontWeight('bold');
    sheet.setFrozenRows(1);
    MONEY_HEADERS.forEach(function (h) {
      var col = headers.indexOf(h) + 1;
      if (col > 0) sheet.getRange(2, col, Math.max(sheet.getMaxRows() - 1, 1), 1).setNumberFormat('$#,##0.00');
    });
  }
  return sheet;
}

/** True if the order reference already appears in column A. */
function refExists_(sheet, ref) {
  var last = sheet.getLastRow();
  if (last < 2) return false;
  return sheet.getRange(2, 1, last - 1, 1)
    .createTextFinder(ref).matchEntireCell(true).findNext() !== null;
}

/** Stop values that look like formulas from executing (CSV/formula injection). */
function sanitize_(value) {
  if (value === null || value === undefined) return '';
  if (typeof value === 'number' || typeof value === 'boolean') return value;
  var s = String(value);
  return /^[=+\-@\t\r]/.test(s) ? "'" + s : s;
}

function toHex_(bytes) {
  return bytes.map(function (b) { return ((b + 256) % 256).toString(16).replace(/^(.)$/, '0$1'); }).join('');
}

/** Constant-time string comparison. */
function safeEqual_(a, b) {
  if (a.length !== b.length) return false;
  var diff = 0;
  for (var i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

/** Optional helper: run once from the editor to generate a strong secret. */
function generateSecret() {
  var secret = Utilities.getUuid().replace(/-/g, '') + Utilities.getUuid().replace(/-/g, '');
  PropertiesService.getScriptProperties().setProperty('WEBHOOK_SECRET', secret);
  Logger.log('WEBHOOK_SECRET set. Copy this value into SHEETS_WEBHOOK_SECRET in .env:\n' + secret);
}
