# Logging checkouts to Google Sheets

Every successful pre-order checkout is added to a Google Sheet, **one row per vehicle**:

| # | Column | Example |
|---|---|---|
| A | Order Reference Number | BYD-CA-261017-8A4D99 |
| B | Date & Time | 2026-10-17 03:00:34 EDT |
| C | Customer Name | Jordan Tremblay |
| D | Email Address | jordan@example.ca |
| E | Province | British Columbia (BC) |
| F | Selected Dealer | Vancouver — Downtown |
| G | Vehicle Model | BYD Seal |
| H | Trim | Design RWD |
| I | Color | Atlantis Grey |
| J | Deposit Amount | $4,000.00 |
| K | Discount Applied | $6,799.60 (pre-order discount + promo code) |
| L | Subtotal | $83,180.40 (price after discounts) |
| M | Tax (GST/PST) | $9,981.65 |
| N | Total Amount | $93,162.05 (subtotal + tax) |
| O–T | Quantity, Interior, Promo Code, Tax Breakdown, Phone, Line Item | 2 · Obsidian Black Nappa · CANADAEV · GST (5%): $4,159.02; PST (7%): $5,822.63 · +1 604 555 0199 · 1 of 2 |

An order with two configurations produces two rows with the same reference number. The rows of one order always add up exactly to the order's tax and total.

## How it works

```
Browser ──fetch POST /api/checkout──▶ Flask (app.py)
                                       │ 1. validate, save order + "log to sheet" job (one transaction)
                                       │ 2. reply 201 → browser opens /confirmation/<ref>
                                       ▼
                         background worker (sheets_logger.py)
                                       │ 3. send rows to Google (signed request)
                                       │    failure → logged, retried later
                                       ▼
                                  Google Sheet
```

* **The browser never contacts Google.** The checkout form is sent with `fetch()` to the Flask server. There is no Google URL, key or secret in any HTML or JavaScript, and the customer never lands on a blank Google page.
* **The customer always sees the confirmation.** Google is contacted only after the order is safely saved. If Google is slow, down or misconfigured, the order still completes. The row is queued and retried after 30 s, 2 min, 10 min, 30 min, 1 h, 3 h, 6 h and 12 h.
* **Errors are logged for the admin** in `logs/sheets.log` and on the admin page `/admin/sheets`.
* **No duplicates.** A double-click or network retry returns the original order (an `Idempotency-Key` header is sent by the cart page), and an order reference already in column A is never written twice.

A spreadsheet with the correct headers is already set up in your Google Drive:
**BYD Canada — Pre-order Log**:
<https://docs.google.com/spreadsheets/d/1ZkoQC7yWH4PN0awFfoT9dud5zUpAem1q5x8aENuIMHo/edit>.
You can use it, or any other sheet; headers are created automatically in an empty tab.

Choose **one** of the two options below. Option A takes about 5 minutes and needs no Google Cloud project.

---

## Option A: Apps Script web app (recommended)

### 1. Add the script to your sheet
1. Open the spreadsheet and choose **Extensions → Apps Script**.
2. Delete the placeholder code in `Code.gs`, then paste the full contents of
   [`integrations/google_sheets/Code.gs`](../integrations/google_sheets/Code.gs).
3. Click **Save** (disk icon). Name the project, e.g. *BYD checkout logger*.

### 2. Create the shared secret
The secret proves to the script that requests come from your server.

1. On your computer, generate a random value:
   ```bash
   python -c "import secrets; print(secrets.token_urlsafe(32))"
   ```
2. In the Apps Script editor, open **Project Settings** (gear icon) → **Script Properties** → **Add script property**:
   * Property: `WEBHOOK_SECRET`
   * Value: the value you generated
3. Click **Save script properties**.

> Alternative: select the `generateSecret` function in the editor toolbar and click **Run**. It stores a secret and prints it in the execution log for you to copy.

### 3. Deploy as a web app
1. Click **Deploy → New deployment**.
2. Click the gear next to *Select type* → **Web app**.
3. Settings:
   * **Description:** Checkout logger
   * **Execute as:** **Me** (your account writes to the sheet)
   * **Who has access:** **Anyone** (required so your server can call it without a Google login; the HMAC signature keeps everyone else out)
4. Click **Deploy**, then **Authorize access**. Choose your account and allow the permissions (if you see "Google hasn't verified this app", choose **Advanced → Go to … (unsafe)**; it is your own script).
5. Copy the **Web app URL**. It looks like `https://script.google.com/macros/s/AKfy…/exec`.

### 4. Configure the server
In the project folder (next to `app.py`):
```bash
cp .env.example .env
```
Edit `.env`:
```ini
SHEETS_WEBHOOK_URL=https://script.google.com/macros/s/AKfy…/exec
SHEETS_WEBHOOK_SECRET=the-same-secret-as-the-script-property
ADMIN_TOKEN=choose-a-long-admin-password
```
Restart the server (`python app.py`).

### 5. Test
```bash
python sheets_logger.py check        # → "Connected to Apps Script; writing to tab 'Pre-orders'."
python sheets_logger.py backfill     # optional: send orders placed before logging was enabled
```
Then place a test pre-order on the site. The row appears within a few seconds.

> **Changing the script later:** after editing `Code.gs`, use **Deploy → Manage deployments → Edit (pencil) → Version: New version → Deploy**. This keeps the same URL. Creating a *new* deployment gives a new URL that must go into `.env`.

---

## Option B: Google Sheets API with a service account

Use this if you prefer not to run Apps Script, or your organisation blocks "Anyone" web apps.

### 1. Create the service account
1. Go to <https://console.cloud.google.com/> and create (or select) a project.
2. **APIs & Services → Library** → search **Google Sheets API** → **Enable**.
3. **APIs & Services → Credentials → Create credentials → Service account**. Give it a name (e.g. `sheets-logger`) → **Done**. No roles are needed.
4. Open the new service account → **Keys → Add key → Create new key → JSON**. A `.json` file downloads.
5. Move it to `credentials/sheets-logger.json` in this project (the folder is git-ignored). **Never** put it under `static/`.

### 2. Share the spreadsheet
Open the JSON file and copy `client_email` (e.g. `sheets-logger@my-project.iam.gserviceaccount.com`). In the spreadsheet click **Share**, paste that address, choose **Editor**, untick *Notify people* and click **Share**.

### 3. Configure the server
```ini
# .env (leave the SHEETS_WEBHOOK_* lines empty)
GOOGLE_SERVICE_ACCOUNT_FILE=credentials/sheets-logger.json
SHEETS_SPREADSHEET_ID=1ZkoQC7yWH4PN0awFfoT9dud5zUpAem1q5x8aENuIMHo
SHEETS_WORKSHEET=Pre-orders
ADMIN_TOKEN=choose-a-long-admin-password
```
The spreadsheet id is the part of the sheet URL between `/d/` and `/edit`. On hosting platforms that do not allow files, paste the whole JSON key on one line into `GOOGLE_SERVICE_ACCOUNT_JSON` instead.

Install dependencies and restart:
```bash
pip install -r requirements.txt
python sheets_logger.py check
python app.py
```

---

## Monitoring and recovery

| Where | What you see |
|---|---|
| `https://<your-site>/admin/sheets` | Connection status, counts (logged / waiting / gave up), the last 50 orders with any error, **Test connection** and **Retry failed orders** buttons. Sign in with any username and `ADMIN_TOKEN` as the password. Returns 404 when `ADMIN_TOKEN` is not set. |
| `logs/sheets.log` | Timestamped log of every delivery, retry and failure (rotates at 1 MB, 5 files kept). Only order references and error messages are logged, not customer details. |
| `python sheets_logger.py status` | Same information in the terminal. |
| `python sheets_logger.py retry` | Re-queue orders that gave up after 8 attempts and send them now. |

Orders are never lost: they are stored in `data/showroom.db` first, and the sheet job stays queued until it succeeds. If you start without any Google configuration, jobs wait and are delivered automatically after you configure a backend and restart.

## Troubleshooting

| Message | Fix |
|---|---|
| `Invalid signature` | `SHEETS_WEBHOOK_SECRET` in `.env` and the `WEBHOOK_SECRET` script property differ. Copy it again, with no spaces or quotes. |
| `Request expired` | The server clock is more than 5 minutes off. Enable NTP time sync. |
| `Apps Script web app not found (HTTP 404)` | The URL is wrong or the deployment was archived. Copy the `/exec` URL from **Deploy → Manage deployments**. |
| `Apps Script did not return JSON` / `refused access` | The deployment's *Who has access* is not **Anyone**, or you copied the `/dev` URL. |
| `Script property WEBHOOK_SECRET is not set` | Add it under Project Settings → Script Properties. |
| `Permission denied (403). Share the spreadsheet with …` | Share the sheet with the service account email as **Editor**. |
| `Spreadsheet not found (404)` | Check `SHEETS_SPREADSHEET_ID`. |
| `The google-auth package is required` | `pip install -r requirements.txt`. |

## Security notes
* Secrets live only in `.env` (or real environment variables) on the server. `.env`, `credentials/`, `logs/` and the database are excluded by `.gitignore`, and none of them are inside the publicly served `static/` folder.
* Webhook requests are signed with HMAC-SHA256 over the timestamp and payload, and are refused after 5 minutes, so a leaked URL alone cannot write to or replay into your sheet.
* Values that start with `=`, `+`, `-` or `@` are stored as plain text (the Apps Script prefixes an apostrophe; the API option writes with `valueInputOption=RAW`), so customer input can never run as a spreadsheet formula.
* The service account only has access to the sheets you explicitly share with it.
* Customer data in the sheet is personal information. Restrict sharing of the spreadsheet to people who need it.
